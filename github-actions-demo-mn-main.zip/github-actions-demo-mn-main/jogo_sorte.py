import random

def jogar():
    numero = random.randint(1, 5)
    return numero == 3  # Ganha se cair 3
