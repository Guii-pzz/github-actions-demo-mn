def soma(a, b):
    return a + b

def test_soma():
    assert soma(2, 3) == 5
